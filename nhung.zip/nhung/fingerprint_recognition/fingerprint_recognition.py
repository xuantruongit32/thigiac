from pyfingerprint.pyfingerprint import PyFingerprint

def recognize_fingerprint():
    try:
        sensor = PyFingerprint('/dev/ttyUSB0', 57600, 0xFFFFFFFF, 0x00000000)

        if not sensor.verifyPassword():
            raise ValueError('Mật khẩu cảm biến không chính xác!')

    except Exception as e:
        print('Không thể khởi tạo cảm biến vân tay!')
        print('Lỗi: ' + str(e))
        exit(1)

    try:
        print('Đặt ngón tay lên cảm biến...')
        while not sensor.readImage():
            pass

        sensor.convertImage(0x01)

        result = sensor.searchTemplate()
        positionNumber = result[0]
        accuracyScore = result[1]

        if positionNumber == -1:
            print('Không tìm thấy vân tay khớp!')
            return False
        else:
            print(f'Vân tay khớp với ID {positionNumber}, độ chính xác: {accuracyScore}')
            return True

    except Exception as e:
        print('Không thể nhận diện vân tay!')
        print('Lỗi: ' + str(e))
        return False
