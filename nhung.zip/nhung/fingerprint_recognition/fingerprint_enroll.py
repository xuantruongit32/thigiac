from pyfingerprint.pyfingerprint import PyFingerprint

def enroll_fingerprint():
    try:
        
        sensor = PyFingerprint('/dev/ttyUSB0', 57600, 0xFFFFFFFF, 0x00000000)

        if not sensor.verifyPassword():
            raise ValueError('Mật khẩu cảm biến không chính xác!')

    except Exception as e:
        print('Không thể khởi tạo cảm biến vân tay!')
        print('Lỗi: ' + str(e))
        exit(1)

    try:
        print('Đặt ngón tay lên cảm biến...')
        while not sensor.readImage():
            pass

        sensor.convertImage(0x01)

        result = sensor.searchTemplate()
        positionNumber = result[0]

        if positionNumber >= 0:
            print('Vân tay đã tồn tại!')
            return

        print('Tháo ngón tay ra...')
        time.sleep(2)

        print('Đặt lại ngón tay lên cảm biến...')
        while not sensor.readImage():
            pass

        sensor.convertImage(0x02)

        if sensor.compareCharacteristics() == 0:
            raise Exception('Hai ngón tay không khớp nhau!')

        sensor.createTemplate()

        positionNumber = sensor.storeTemplate()
        print(f'Vân tay đã được lưu vào vị trí {positionNumber}')

    except Exception as e:
        print('Không thể đăng ký vân tay!')
        print('Lỗi: ' + str(e))
