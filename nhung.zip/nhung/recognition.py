
from fingerprint_recognition.fingerprint_recognition import recognize_fingerprint
from facial_req import check_face_recognition

def integrated_recognition():
    print('Bắt đầu xác thực...')

    # Kiểm tra vân tay trước
    if recognize_fingerprint():
        print('Vân tay hợp lệ, mở khóa...')
        return True
    else:
        print('Vân tay không khớp, kiểm tra khuôn mặt...')

    # Nếu vân tay không khớp, kiểm tra khuôn mặt
    if check_face_recognition():
        print('Khuôn mặt hợp lệ, mở khóa...')
        return True
    else:
        print('Khuôn mặt không khớp, từ chối truy cập.')
        return False

if __name__ == "__main__":
    integrated_recognition()
